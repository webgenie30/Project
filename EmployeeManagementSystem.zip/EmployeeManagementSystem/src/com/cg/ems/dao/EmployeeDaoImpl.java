package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;
import com.cg.ems.util.ConnectionProvider;





public class EmployeeDaoImpl implements IEmployeeDao {

	static Logger logger = Logger.getLogger(EmployeeDaoImpl.class);
	Connection connection = null;
	PreparedStatement statement = null;
	
	
	public Employee selectStatements(ResultSet resultSet) throws SQLException {
		Employee employee = new Employee();
		employee.setEmployeeId(resultSet.getString(1));
		employee.setEmpFName(resultSet.getString(2));
		employee.setEmpLName(resultSet.getString(3));
		employee.setEmpDOB(resultSet.getDate(4));
		employee.setEmpDOJ(resultSet.getDate(5));
		employee.setDeptId(resultSet.getInt(6));
		employee.setEmpGrade(resultSet.getString(7));
		employee.setEmpDesignation(resultSet.getString(8));
		employee.setEmpBasic(resultSet.getInt(9));
		employee.setEmpGender(resultSet.getString(10));
		employee.setEmpMStatus(resultSet.getString(11));
		employee.setHomeAddr(resultSet.getString(12));
		employee.setEmpCNumber(resultSet.getString(13));
		employee.setMrgId(resultSet.getString(14));

		return employee;
	}
	
	@Override
	public int applyLeave(LeaveHistory leaveHistory) throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		int leaveId = 0;
		int queryResult = 0;

		try {
			preparedStatement = connection
					.prepareStatement(IQueryMapper.LEAVE_REQUEST_QUERY);
			preparedStatement.setString(1, leaveHistory.getEmpId());
			preparedStatement.setInt(2, leaveHistory.getLeaveBalance());
			int days = leaveHistory.getNoofdays();
			preparedStatement.setInt(3, days);
			preparedStatement.setDate(4,
					java.sql.Date.valueOf(leaveHistory.getDateFrom()));
			LocalDate startDate = leaveHistory.getDateFrom();
			LocalDate endDate = addDays(startDate, days);
			preparedStatement.setDate(5, java.sql.Date.valueOf(endDate));
			preparedStatement.setString(6, "applied");
			queryResult = preparedStatement.executeUpdate();
			preparedStatement.close();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.LEAVEID_QUERY_SEQUENCE);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				leaveId = resultSet.getInt(1);

			}

			if (queryResult == 0) {
				logger.error("Application for leave failed ");
				throw new EMSException("Inserting Leave details failed ");
			} else {
				logger.info("Leave details added successfully:");
				return leaveId;
			}
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured refer log");
		}

		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}
		
	}
	
	// Add Days to leave start date taking into account weekends
		private LocalDate addDays(LocalDate date, int workdays) {
			if (workdays < 1) {
				return date;
			}

			LocalDate result = date;
			int addedDays = 0;
			while (addedDays < workdays) {
				result = result.plusDays(1);
				if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result
						.getDayOfWeek() == DayOfWeek.SUNDAY)) {
					++addedDays;
				}
			}

			return result;
		}
		
		
	@Override
	public Employee viewEmployeeById(String empId) throws EMSException {
		connection = ConnectionProvider.getConnection();

		PreparedStatement preparedStatement = null;

		ResultSet resultSet = null;
		Employee employee = null;
		
		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.SELECT_BY_ID);
			preparedStatement.setString(1, empId);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employee = new Employee();
				employee = selectStatements(resultSet);

			}
			if (employee != null) {
				logger.info("Record Found Successfully");
				return employee;
			} else {
				logger.info("Record Not Found Successfully");
				return null;
			}

		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new EMSException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException exception) {
				logger.error(exception.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}
	}
	@Override
	public Employee viewEmployeeByFname(String firstName) throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Employee employee = null;

		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.SELECT_BY_FNAME);
			preparedStatement.setString(1, firstName);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employee = new Employee();
				employee = selectStatements(resultSet);
			}
			if (employee != null) {
				logger.info("Record Found Successfully");
				return employee;
			} else {
				logger.info("Record Not Found Successfully");
				return null;
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new EMSException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException exception) {
				logger.error(exception.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}
	}
	@Override
	public Employee viewEmployeeByLname(String lastName) throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		Employee employee = null;

		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.SELECT_BY_LNAME);
			preparedStatement.setString(1, lastName);
			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employee = new Employee();
				employee = selectStatements(resultSet);
			}
			if (employee != null) {
				logger.info("Record Found Successfully");
				return employee;
			} else {
				logger.info("Record Not Found Successfully");
				return null;
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new EMSException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException exception2) {
				logger.error(exception2.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}
	}
	@Override
	public List<Employee> viewEmployeeByDeptName(String deptName)
			throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		int empCount = 0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Employee> employeeList = new ArrayList<Employee>();

		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.SELECT_BY_DEPT_NAME);
			preparedStatement.setString(1, deptName);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Employee employee = new Employee();
				employee = selectStatements(resultSet);

				employeeList.add(employee);
				empCount++;
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new EMSException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new EMSException("Error in closing db connection");

			}
		}
		if (empCount == 0)
			return null;
		else
			return employeeList;
	}
	@Override
	public List<Employee> viewEmployeeByGrade(String empGrade)
			throws EMSException {
		Connection connection = ConnectionProvider.getConnection();

		int empCount = 0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Employee> employeeList = new ArrayList<Employee>();

		try {
			preparedStatement = connection.prepareStatement(IQueryMapper.SELECT_BY_GRADE);
			preparedStatement.setString(1, empGrade);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Employee employee = new Employee();
				employee = selectStatements(resultSet);

				employeeList.add(employee);
				empCount++;

			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new EMSException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException exception2) {
				logger.error(exception2.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}
		if (empCount == 0)
			return null;
		else
			return employeeList;
	}
	@Override
	public List<Employee> viewEmployeeByMaritalStatus(String maritalStatus)
			throws EMSException {
		Connection connection =ConnectionProvider.getConnection();

		int empCount = 0;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		List<Employee> employeeList = new ArrayList<Employee>();

		try {
			preparedStatement = connection
					.prepareStatement(IQueryMapper.SELECT_BY_MARITAL_STATUS);
			preparedStatement.setString(1, maritalStatus);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Employee employee = new Employee();
				employee = selectStatements(resultSet);

				employeeList.add(employee);
				empCount++;

			}
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new EMSException(exception.getMessage());
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException exception2) {
				logger.error(exception2.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}
		if (empCount == 0)
			return null;
		else
			return employeeList;
	}
	@Override
	public List<Employee> retriveAllDetails() throws EMSException {
		Connection con = ConnectionProvider.getConnection();
		int empCount = 0;

		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;

		List<Employee> employeeList = new ArrayList<Employee>();
		try {
			preparedStatement = con.prepareStatement(IQueryMapper.RETRIEVE_ALL_DETAILS);
		
			resultset = preparedStatement.executeQuery();

			while (resultset.next()) {
				Employee employee = new Employee();
				employee = selectStatements(resultset);

				employeeList.add(employee);
				empCount++;
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new EMSException("Tehnical problem occured!!");
		}

		finally {
			try {
				resultset.close();
				preparedStatement.close();
				con.close();
			} catch (SQLException exception) {
				logger.error(exception.getMessage());
				throw new EMSException("Error in closing db connection");
			}
		}

		if (empCount == 0)
			return null;
		else
			return employeeList;
	}

	}
	
