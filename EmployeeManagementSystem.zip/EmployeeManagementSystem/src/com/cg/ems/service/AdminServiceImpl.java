package com.cg.ems.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import com.cg.ems.dao.AdminDaoImpl;
import com.cg.ems.dao.EmployeeDaoImpl;
import com.cg.ems.dao.IAdminDao;
import com.cg.ems.exception.EMSException;
import com.cg.ems.model.Employee;
import com.cg.ems.model.LeaveHistory;

public class AdminServiceImpl implements IAdminService{
	
	IAdminDao dao=new AdminDaoImpl();

	@Override
	public String addEmployee(Employee employee) throws EMSException {
		
		String empId;
		empId = dao.addEmployee(employee);
		return empId;
	}
	

	@Override
	public Employee updateEmployeeById(Employee employee) throws EMSException {
		Employee updateEmployee = dao.updateEmployeeById(employee);
		return updateEmployee;
	}
	

	@Override
	public boolean leaveSanction(int leaveId, String status) throws EMSException {
		boolean updateStatus = false;
		updateStatus = dao.leaveSanction(leaveId, status);
		return updateStatus;
	}

	@Override
	public List<LeaveHistory> viewLeaveApplications() throws EMSException {
		List<LeaveHistory> leaveList = new ArrayList<LeaveHistory>();
		leaveList = dao.viewLeaveApplications();
		return leaveList;
	}

	@Override
	public void validateLeave(LeaveHistory leave,String empId) throws EMSException {
		List<String> validationErrors = new ArrayList<String>();

		if (!(isValidStartDate(leave.getDateFrom()))) {
			validationErrors
					.add("\n Leave start date should be after current date \n");
		}

		if (!(sufficientLeaveRemaining(leave.getNoofdays(),getRemainingLeaves(empId)
				))) {
			System.out.println("noofdays"+leave.getNoofdays());
			System.out.println("noofdays"+getRemainingLeaves(empId));
			validationErrors
					.add("\n Leave duration must not exceed remaining leaves \n");
		}

		if (!validationErrors.isEmpty())
			throw new EMSException(validationErrors + "");
	}
	
	public boolean isValidStartDate(LocalDate startDate) {
		LocalDate date = LocalDate.now();
		return (!startDate.isBefore(date));
	}
	
	public boolean sufficientLeaveRemaining(long l, int remainingLeaves) {
		return (remainingLeaves >= l);
	}

	@Override
	public int getRemainingLeaves(String empId) throws EMSException {
		return dao.getRemainingLeaves(empId);
	}

	@Override
	public List<LeaveHistory> checkAppliedLeaves(String empId) throws EMSException {
		List<LeaveHistory> leaveList = new ArrayList<LeaveHistory>();
		leaveList = dao.checkAppliedLeaves(empId);
		return leaveList;
	}
	}

	


